import { createPinia } from 'pinia';

export const usePinia = createPinia();