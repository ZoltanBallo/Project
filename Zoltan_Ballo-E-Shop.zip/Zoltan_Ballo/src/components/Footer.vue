<template>
    <v-footer color="indigo" app height="50px">
      <v-container>
        <v-row justify="center">
          <v-col class="text-center">
            <h3 class="white--text">Zoltán Bálló</h3>
            <p class="white--text">Univerzita Konštantína Filozofa v Nitre</p>
          </v-col>
        </v-row>
      </v-container>
    </v-footer>
  </template>
  
  <script>
  export default {
    name: 'Footer',
  };
  </script>