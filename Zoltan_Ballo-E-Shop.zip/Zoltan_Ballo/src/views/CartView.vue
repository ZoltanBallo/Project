<template>
    <Cart />
  </template>
  
  <script>
  import Cart from '@/components/Cart.vue';
  
  export default {
    components: {
      Cart
    }
  };
  </script>
  